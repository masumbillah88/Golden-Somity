<?php

use App\Models\User;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\DepositController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\TransactionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Page Routes:

Route::view('/', 'pages.home');
Route::view('/app', 'layout.app');
Route::view('/sidenav', 'layout.sidenav-layout');
Route::view('/userRegistration', 'pages.auth.registration-page');
Route::view('/userlogin', 'pages.auth.login-page')->name('login');
Route::view('/reset-pass', 'pages.auth.reset-pass-page');
Route::view('/send-otp', 'pages.auth.reset-pass-page');
Route::view('/verify-otp', 'pages.auth.verify-otp-page');
Route::view('/profile', 'pages.dashboard.profile-page');
Route::view('/sendOtp', 'pages.auth.send-otp-page');
Route::view('verifyOtp', 'pages.auth.verify-otp-page');
Route::view('resetPassword', 'pages.auth.reset-pass-page');
Route::view('/CreateAccount','pages.dashboard.accounts-page');
Route::view('/customer-page', 'pages.dashboard.customer-page');
Route::view('/make-deposit', 'pages.dashboard.deposit-page');
Route::view('/make-deposit01', 'pages.dashboard.deposit01-page');
Route::view('/make-deposit02', 'pages.dashboard.deposit-page01');








//Back-end Routes:
Route::post('/userRegistration', [UserController::class, 'userRegistration']);
Route::post('/Login', [UserController::class, 'userLogin']);
Route::get('/user-profile', [UserController::class, 'userProfile'])->middleware('auth:sanctum');
Route::post('/updateProfile', [UserController::class, 'updateProfile'])->middleware('auth:sanctum');
Route::get('/Logout', [UserController::class, 'userLogout'])->name('Logout')->middleware('auth:sanctum');
Route::post('/send-otp', [UserController::class, 'sendOtp']);
Route::post('/verify-otp', [UserController::class, 'verifyOtp']);
Route::post('/reset-password', [UserController::class, 'ResetPassword'])->middleware('auth:sanctum');
Route::post('/create-category', [CategoryController::class, 'CreateCategories'])->middleware('auth:sanctum');
Route::post('/update-category', [CategoryController::class, 'UpdateCategory'])->middleware('auth:sanctum');
Route::get('/account-list', [AccountController::class, 'AccountList'])->middleware('auth:sanctum');
Route::post('/delete-category', [CategoryController::class, 'DeleteCategory'])->middleware('auth:sanctum');
Route::post('/create-customer', [CustomerController::class, 'CreateCustomer'])->middleware('auth:sanctum');
Route::post('/create-account', [AccountController::class, 'CreateAccount'])->middleware('auth:sanctum');
Route::post('/deposit', [TransactionController::class, 'Deposit'])->middleware('auth:sanctum');
Route::post('/withdraw', [TransactionController::class, 'withdraw'])->middleware('auth:sanctum');
Route::get('/list-customer',[CustomerController::class, 'getCustomerList'])->middleware('auth:sanctum');
Route::post('/make-deposit',[TransactionController::class, 'getAccountInfo'])->name('getAccountInfo');
Route::get('/make-deposit',[TransactionController::class, 'getAccountInfo'])->name('getAccountInfo');

//Route::get('/make-deposit01',[TransactionController::class, 'getCustomerList'])->middleware('auth:sanctum')->name('make-deposit01');

