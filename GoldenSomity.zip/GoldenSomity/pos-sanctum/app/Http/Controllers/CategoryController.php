<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{
    public function CreateCategories(Request $request){
        try{
            $request->validate([
                'categoryName' => 'required|string|max:50'
            ]);
            $user_id = Auth::id();
            Category::create([
                'categoryName' => $request->input('categoryName'),
                'user_id' => $user_id
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Category Created successfully'
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
        
    }
    public function UpdateCategory(Request $request){
        try{
            $request->validate([
                'id' => 'required|integer|min:1',
                'categoryName' => 'required|string|min:2'
            ]);
            $category_id = $request->input('id');
            $user_id = Auth::id();
            Category::where('id',$category_id)->where('user_id',$user_id)->update([
                'categoryName' => $request->input('categoryName')
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Category Updated successfully']);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()]);
        }
       
    }
    public function CategoryList(Request $request){
        Category::all();
    }
    public function DeleteCategory(Request $request)
    { 
        try{
            $request->validate([
                'id' => 'required|min:1'
            ]);
            $user_id = Auth::id();
            $category_id = $request->input('id');
            Category::where('id',$category_id)->where('user_id', $user_id)->delete();
            return response()->json([
                'status' => 'success',
                'message' => 'Category Deleted successfully'
            ]);

        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()]);
        }
        

        
    }
}
