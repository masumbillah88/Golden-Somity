<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Account;
use App\Models\Balance;
use App\Models\Deposit;
use App\Models\Withdraw;
use App\Models\TotalDeposit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    public function getAccountInfo(Request $request){
        try{
            $account_number = $request->input('account_number');
            $rows = Account::where('account_number',$account_number)->get();
            
            if(!$rows){
                return response('Account Not Found');
            }
            return view('pages.dashboard.deposit-page', compact('rows'));
            //  return response()->json([
            //     'status' => 'success',
            //     'rows' => $rows
            //  ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
}
    
    public function Deposit(Request $request){
        try{
            $user_id = Auth::id();
            $account_number = $request->input('account_number');
            $amount = $request->input('deposit');
            $account = Account::where('account_number',$account_number)->first();
            if(!$account){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Account Not found.'
                ]);
            }
            Deposit::create([
                'user_id' => $user_id,
                'account_number' => $account_number,
                'deposit' => $amount
            ]);
            //Balance::where('account_number', $account_number)->increment('balance',$amount);
            Balance::updateOrcreate(['account_number' => $account_number],
                ['balance' => DB::raw("balance+$amount")]
        );
            //$account->deposits()->increment('balance', $amount);
            $total_deposit = DB::table('balances')->sum('balance');
         TotalDeposit::updateOrcreate(['id'=>2],['total_deposit' => DB::raw("$total_deposit")]);

            return response()->json([
                'status' => 'success',
                'message' => 'Deposit Successfull'
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
        
    }
    public function withdraw(Request $request){
        try{
            $user_id = Auth::id();
            $account_number = $request->input('account_number');
            $amount = $request->input('withdraw');
            $account = Account::where('account_number',$account_number)->first();
            if(!$account){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Account Not found.'
                ]);
            }
            $balance = Balance::where('account_number', $account_number)->first();
            $Availbalance = $balance->balance;
            
            if($amount>$Availbalance){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Insufficient balance.'
                ]);
            }else{
                Withdraw::create([
                    'user_id' => $user_id,
                    'account_number' => $account_number,
                    'withdraw' => $amount
                ]);
                 //Balance::where('account_number', $account_number)->increment('balance',$amount);
                 Balance::updateOrcreate(['account_number' => $account_number],
                 ['balance' => DB::raw("balance-$amount")]
         );
         $total_deposit = DB::table('balances')->sum('balance');
         TotalDeposit::updateOrcreate(['id'=>2],['total_deposit' => DB::raw("total_deposit-$total_deposit")]);

         
         return response()->json([
             'status' => 'success',
             'message' => 'Withdraw Successfull.'
         ]);
            }  
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
       
    }
    
}
