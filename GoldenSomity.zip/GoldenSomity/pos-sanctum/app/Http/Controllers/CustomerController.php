<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\Auth;

class CustomerController extends Controller
{
    public function CreateCustomer(Request $request){
        try{
            Customer::create([
                'id' => $request->input('id'),
                'name' => $request->input('name'),
                'fathers_name' => $request->input('fathers_name'),
                'mothers_name' => $request->input('mothers_name'),
                'address' => $request->input('address'),
                'phone_number' => $request->input('phone_number'),
                'nid' => $request->input('nid')
            ]);  
            return response()->json([
                'status' => 'success',
                'message' => 'Customer Created Successfully.'
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
        


    }
    public function getCustomerList(Request $request){
        try{
            
            $rows = Customer::all();
            return response()->json([
                'status' => 'success',
                'rows' => $rows
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
            
        }
        
        
    }
}
