<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\User;
//use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\OtpMail;

class UserController extends Controller
{
    public function userRegistration(Request $request){
        $request->validate([
            'first_name' => 'required|string|max:50',
            'last_name' => 'required|string|max:50',
            'email' => 'required|email|string|max:50',
            'mobile' => 'required|max:50',
            'password' => 'required|string|min:3'
         ]);
         try{
            User::create([
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'email' => $request->input('email'),
                'mobile' => $request->input('mobile'),
                'password' => $request->input('password')
    
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'User registration successfull.'
            ]);
         }catch(Exception $exception){
            return response()->json([
                'status' => 'failed',
                'message' => $exception->getMessage()
            ]);
            
            
         }
         
        
    }
    public function userLogin(Request $request){
        try{
            $request->validate([
                'email' => 'required|string|email|max:50',
                'password' => 'required|string|min:3'
            ]);
            $user = User::where('email', $request->input('email'))->first();
            if(!$user||!Hash::check($request->input('password'), $user->password)){
                return response()->json(['status'=>'failed', 'message'=>'User is invalid']);
            
                

            }else{
                $token = $user->createToken('authToken')->plainTextToken;
                return response()->json([
                    'status' => 'success',
                    'message' => 'User Login Successfull.',
                    'token' => $token

                ]);
            }
        }catch(Exception $e){

        }


        
        
    }
    public function userProfile(Request $request){
        
        return Auth::user();
    }

    public function updateProfile(Request $request){
        
        try{
            $request->validate([
                'first_name' => 'required|string|max:50',
                'last_name' => 'required|string|max:50',
                'email' => 'required|string|email|max:50',
                'mobile' => 'required|string|min:11|max:50'
    
            ]);
            User::where('id', '=', Auth::id())->update([
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'email' => $request->input('email'),
                'mobile' => $request->input('mobile')
    
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'User Information Successfully Updated.'
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
        

    }
    public function userLogout(Request $request){
        $request->user()->tokens()->delete();
        return redirect('userlogin');
    }
    public function sendOtp(Request $request){
        try{
            $email = $request->input('email');
            $otp = rand(100000,999999);
            $count = User::where('email', '=', $email)->count();
            if($count == 1){
                Mail::to($email)->send(new OtpMail($otp));
                User::where('email', '=', $email)->update(['otp'=>$otp]);
                return response()->json([
                    'status' => 'success',
                    'message' => 'OTP sent Successfully.'
                ]);
                }else{
                return response()->json([
                    'status'  => 'failed',
                    'message' => 'Invalid Email Address'
                ]);
            }
        
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
       
    }
    public function verifyOtp(Request $request){
        try{
            $request->validate([
                'email' => 'required|email|max:50',
                'otp' => 'required|min:6'
            ]);
            $email = $request->input('email');
            $otp = $request->input('otp');
            $user = User::where('email', '=', $email)->where('otp', '=', $otp)->first();
            if(!$user){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Invalid Otp'
                ]);
            }
            User::where('email', '=', $email)->update(['otp'=>0]);
            $token = $user->createToken('authToken')->plainTextToken;
            return response()->json([
                'status' => 'success',
                'message' => 'OTP Verification successfull.',
                'token' => $token
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
       
    }
    public function ResetPassword(Request $request){
        try{
            $request->validate([
                'password' => 'required|min:3'
            ]);
        $id = Auth::id();
        $password = $request->input('password');
        User::where('id', '=', $id)->update(['password'=> Hash::make($password)]);
        return response()->json([
            'status' => 'success',
            'message' => 'Password Updated Successfully.'
        ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
    }
}
