<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Account;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AccountController extends Controller
{
    public function CreateAccount(Request $request){
        try{
            $id = $request->input('id');
            
            $customer = Customer::find($id);
            $user_id = Auth::id();
            //$account_number = rand(100,999);
            //$customer_id = $customer->id;
            if(!$customer){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'customer not found']);
            }
            
            // dd($customer_id);
            $titleOfAccount = $customer->name;
           $account = $customer->accounts()->create([
                'user_id' => $user_id,
                'titleOfAccount' => $titleOfAccount,
                
                'type' => $request->input('type'),
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Account Created Successfully.'
            ]);
        }catch(Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => $e->getMessage()
            ]);
        }
        

    }
    public function AccountList(Request $request){
        try{
            $rows = Account::all();
                       
            return response()->json([
                'status' => 'success',
                'rows' => $rows,
                
            ]);
        }catch(Exception $e){
        return response()->json([
            'status' => 'failed',
            'message' => $e->getMessage()
        ]);
    }

    }
}
