<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'name',
        'fathers_name',
        'mothers_name',
        'address',
        'phone_number',
        'nid'
    ];

    public function accounts(){
        return $this->hasMany(Account::class);
    }
}
