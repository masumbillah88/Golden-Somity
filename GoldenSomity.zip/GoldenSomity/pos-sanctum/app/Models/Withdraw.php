<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Withdraw extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'account_number',
        'withdraw'
    ];
    public function account(){
        return $this->belongsTo(Account::class,'account_number');
    }
}
