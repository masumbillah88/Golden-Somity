<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    //use HasFactory;
    protected $fillable = [
        'customer_id',
        'user_id',
        'titleOfAccount',
        'account_number',
        'type',
        
    ];
    public function balance(){
        return $this->hasOne(Balance::class, 'account_id');
    }
    public function deposits(){
        return $this->hasMany(Deposit::class,'account_number');
    }
    protected static function boot(){
        parent::boot();
        static::creating(function($account){
            $account->account_number = date('Ymd').sprintf('%03d', self::max('id')+1);
        });

        
    }
}
