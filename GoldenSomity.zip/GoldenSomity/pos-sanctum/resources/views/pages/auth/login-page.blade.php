@extends('layout.app')
@section('content')
    @include('components.auth.login-form')
@endsection

