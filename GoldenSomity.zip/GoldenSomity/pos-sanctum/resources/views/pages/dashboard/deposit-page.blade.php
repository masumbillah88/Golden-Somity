@extends('layout.sidenav-layout')
@section('content')
    @include('components.deposit.make-deposit')
    <!-- @include('components.accounts.category-delete')
    @include('components.accounts.create-account')
    @include('components.accounts.category-update') -->
@endsection