@extends('layout.sidenav-layout')
@section('content')
    @include('components.deposit.make-deposit01')
    <!-- @include('components.accounts.category-delete')
    @include('components.accounts.create-account')
    @include('components.accounts.category-update') -->
@endsection