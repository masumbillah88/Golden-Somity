<div class="container-fluid">
    <div class="row">
    <div class="col-md-4 col-sm-12 col-lg-12">
        <div class="card px-5 py-5">
            <div class="row justify-content-between ">
                <div class="align-items-center col">
                    <h4>Make Deposit</h4>
                </div>
                
            </div>
            <hr class="bg-warning"/>
            <div class="table-responsive">
            <table class="table" id="tableData">
            @foreach($rows as $row)
                <thead>
                
                <tr class="bg-info">
                    <th class = "text-dark">Customer Id</th>
                    <td class = "text-dark">{{$row->customer_id}}</td>
                    </tr>
                    
                    <tr class="bg-light">
                    <th>Title of Account</th>
                    <td class = "text-dark">{{$row->titleOfAccount}}</td>
                    </tr>
                    <tr class="bg-light">
                    <th>Account Number</th>
                    <td class = "text-dark">{{$row->account_number}}</td>
                    </tr>
                    <tr class="bg-light">
                    <th>Date of Opening</th>
                    <td class = "text-dark">{{$row->created_at->format('d-m-Y')}}</td>
                    </tr>
                    
                </tr>
                </thead>                   

                @endforeach
                <tbody id="tableList" style = "float:left">
                </tbody>
            </table>
            
            <label><h3>Accouont Number</h3></label>
            <input id="account_number" value = "{{$row->account_number}}"  class="form-control w-50" type="email"/>
            <label><h3>Amount</h3></label>
            <input id="deposit" type = "text" class="form-control w-50"/>
            <button onclick = "Save()" type = "submit" class="btn mt-3 w-50  bg-gradient-dark">Make Deposit</button>

            </div>
        </div>
    </div>
</div>
</div>



<script>

    async function Save() {

        try {
            let account_number = document.getElementById('account_number').value;
            let deposit = document.getElementById('deposit').value;
                     
            showLoader();
            let res = await axios.post("/deposit",{account_number:account_number,deposit:deposit},HeaderToken())
            hideLoader();
            console.log(res);
            if(res.data['status']==="success"){
                successToast(res.data['message']);
                document.getElementById("save-form").reset();
                window.location.href="/make-deposit02";
                
            }
            else{
                errorToast(res.data['message'])
            }

        }catch (e) {
            unauthorized(e.response.status)
        }

    }

</script>


