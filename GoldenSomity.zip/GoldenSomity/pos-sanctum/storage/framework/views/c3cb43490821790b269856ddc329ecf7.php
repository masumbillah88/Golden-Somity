<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-10 center-screen">
            <div class="card animated fadeIn w-100 p-3">
                <div class="card-body">
                    <h4>Make Deposit</h4>
                    <hr/>
                    <div class="container-fluid m-0 p-0">
                        <div class="row m-0 p-0">
                            
                            <div class="col-md-4 p-2">
                            <form method="POST" action="<?php echo e(route('getAccountInfo')); ?>">
                               <?php echo csrf_field(); ?>
                               <?php echo method_field('post'); ?>
                                <label>Account Number</label>
                                <input name = "account_number" id="account_number" placeholder="Enter Account Number" class="form-control" type="text"/>
                                <button type = "submit" class="btn mt-3 w-100  bg-gradient-dark">Submit</button>
                           <!-- </form> -->
                            </div>
                            

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- <script>
    async function getAccountInfo(){
        let account_number = document.getElementById('account_number').value;
        if(account_number.length === 0){
            erroToast("Account Number is Required");
        }else{
            showLoader();
            let res = axios.post("/make-deposit", HeaderToken(),{account_number:account_number});
            hideLoader();
            //window.location("/deposit-page");
        }
    }
</script> -->



<?php /**PATH /Users/muhammadmasumbillah/GoldenSomity/pos-sanctum/resources/views/components/deposit/make-deposit01.blade.php ENDPATH**/ ?>